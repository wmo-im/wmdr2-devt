# WMDR2 schema refactor — temporal fix

The remaining 11 failures all had the same cause: `time.resolution`.

The pinned WCMP YAML itself contains an over-escaped ISO-8601 duration regular
expression. Therefore referring to the complete upstream WCMP `time` schema
still rejects valid values such as `P1D` and `PT1H`.

This update keeps the official reuse architecture but narrows the exception:

- reuse pinned WCMP `date`;
- reuse pinned WCMP `timestamp`;
- reuse pinned WCMP `interval`;
- validate only `resolution` with the corrected local ISO-8601 duration rule.

No converter changes are included.

Apply:

```bash
unzip -o wmdr2_schema_time_fix.zip
pytest
```

No schema resynchronization or reconversion is required for this fix.
