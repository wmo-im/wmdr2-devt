# WMDR2 development schemas

The development schema is modular and reuses the official WMDR2 schema rather
than maintaining a parallel copy.

```text
official wmo-im/wmdr2 (pinned snapshot)
        │
        ├── record/Facility properties ──────────────┐
        ├── Observation controlled properties ──────┤
        ├── Configuration properties ───────────────┤
        └── Instrument base ─────────────────────────┤
                                                    ▼
wmdr2-devt local modules
  wmdr2-common.schema.json
  wmdr2-instrument.schema.json
  wmdr2-configuration.schema.json
  wmdr2-observation.schema.json
  wmdr2-facility-properties.schema.json
  wmdr2-record-feature.schema.json
```


The official schema is used as a source of compatible property and class constraints. The development schema does **not** inherit the complete official record with `allOf`, because that would also import official cardinalities and the currently incompatible embedded-Instrument constraint. Existing wmdr2-devt cardinalities are therefore preserved explicitly while compatible official definitions are referenced directly.

The authoritative entry point for a full development record remains:

`schemas/wmdr2-record-feature.schema.json`

Official definitions are referenced using an immutable raw-GitHub URL pinned
to `wmo-im/wmdr2@d30f13c3be6395466a778360c4a4ef59625be6af`.
For offline/local validation, fetch the exact verified snapshot once:

```bash
python schemas/sync_official_wmdr2_schema.py
# or, if you have a local wmo-im/wmdr2 clone at the pinned commit:
python schemas/sync_official_wmdr2_schema.py --source ~/Public/git/wmdr2/schemas/wmdr2-bundled.json
```

The local `official/wmdr2-bundled.json` is only a verified cache of that exact
upstream artifact; it must not be edited.

### WCMP time dependency

The official modular WMDR2 schemas delegate `time` to WCMP. At the pinned WCMP revision, the `resolution` regular expression is over-escaped in the WCMP YAML itself, and the generated WMDR2 bundle inherits the same problem. Consequently, valid values such as `P1D` and `PT1H` are rejected by the upstream `resolution` constraint. wmdr2-devt therefore reuses the pinned WCMP `date`, `timestamp`, and `interval` sub-schemas directly, while isolating only `resolution` behind a corrected local ISO-8601 duration constraint. The WCMP snapshot remains pinned at `wmo-im/wcmp2@f05037aa8d8bf5911a44a511b7b99a0be009c9ab` (Git blob `73ac9326613473e2534b48c7b33ab6eb1f1e50b3`).
